# Type Test
 first project of Programming course
